#pragma once

#include <Windows.h>

bool isInternalUser(bool setValue = true);
void deleteRegKey(bool popBubb = true, bool popWin = true);